from django.test import TestCase
from core.forms import LinkForm


class LinkFormTest(TestCase):

    def test_form_tem_campos_corretos(self):
        form = LinkForm()
        expected = ['titulo', 'link', 'observacao']
        self.assertSequenceEqual(expected, list(form.fields))

    def test_form_valido(self):
        dados = {
            'titulo': 'Google',
            'link': 'https://google.com',
            'observacao': 'Site de pesquisa'
        }

        form = LinkForm(data=dados)

        self.assertTrue(form.is_valid())

    def test_form_link_invalido(self):
        dados = {
            'titulo': 'Google',
            'link': 'link errado',
            'observacao': 'Site de pesquisa'
        }

        form = LinkForm(data=dados)

        self.assertFalse(form.is_valid())
        self.assertIn('link', form.errors)

    def test_observacao_pode_ser_vazia(self):
        dados = {
            'titulo': 'Google',
            'link': 'https://google.com',
            'observacao': ''
        }

        form = LinkForm(data=dados)

        self.assertTrue(form.is_valid())