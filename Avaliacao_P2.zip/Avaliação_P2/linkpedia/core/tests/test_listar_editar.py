from django.contrib.auth.models import User
from django.test import TestCase, Client
from django.urls import reverse
from core.models import LinkModel


class ListarEditarTest(TestCase):

    def setUp(self):
        self.client = Client()

        self.user = User.objects.create_user(
            username="admin",
            email="admin@cps.sp.gov.br",
            password="123mudar"
        )

        self.link = LinkModel.objects.create(
            titulo="Google",
            link="https://google.com",
            observacao="Site de pesquisa"
        )

    def test_listar_precisa_de_login(self):
        response = self.client.get(reverse("listar"))

        self.assertEqual(response.status_code, 302)

    def test_listar_logado_abre_pagina(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("listar"))

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "listar.html")

    def test_listar_mostra_link_cadastrado(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("listar"))

        self.assertContains(response, "Google")
        self.assertContains(response, "https://google.com")
        self.assertContains(response, "Site de pesquisa")

    def test_editar_precisa_de_login(self):
        response = self.client.get(reverse("editar", args=[self.link.id]))

        self.assertEqual(response.status_code, 302)

    def test_editar_get_logado_abre_pagina(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("editar", args=[self.link.id]))

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "editar.html")
        self.assertContains(response, "Google")
        self.assertContains(response, "https://google.com")

    def test_editar_post_valido_atualiza_link(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google Atualizado",
            "link": "https://google.com.br",
            "observacao": "Site atualizado"
        }

        response = self.client.post(
            reverse("editar", args=[self.link.id]),
            dados
        )

        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse("listar"))

        self.link.refresh_from_db()

        self.assertEqual(self.link.titulo, "Google Atualizado")
        self.assertEqual(self.link.link, "https://google.com.br")
        self.assertEqual(self.link.observacao, "Site atualizado")

    def test_editar_post_invalido_nao_atualiza_link(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google Atualizado",
            "link": "link errado",
            "observacao": "Site atualizado"
        }

        response = self.client.post(
            reverse("editar", args=[self.link.id]),
            dados
        )

        self.assertEqual(response.status_code, 200)

        self.link.refresh_from_db()

        self.assertEqual(self.link.titulo, "Google")
        self.assertEqual(self.link.link, "https://google.com")
        self.assertEqual(self.link.observacao, "Site de pesquisa")