from django.contrib.auth.models import User
from django.test import TestCase, Client
from django.urls import reverse
from core.models import LinkModel


class CadastroTest(TestCase):

    def setUp(self):
        self.client = Client()

        self.user = User.objects.create_user(
            username="admin",
            email="admin@cps.sp.gov.br",
            password="123mudar"
        )

    def test_cadastro_precisa_de_login(self):
        response = self.client.get(reverse("cadastro"))

        self.assertEqual(response.status_code, 302)

    def test_cadastro_get_logado(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("cadastro"))

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "cadastro.html")
        self.assertContains(response, "Cadastro de Link")

    def test_cadastro_post_valido_salva_link(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google",
            "link": "https://google.com",
            "observacao": "Site de pesquisa"
        }

        response = self.client.post(reverse("cadastro"), dados)

        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse("listar"))
        self.assertEqual(LinkModel.objects.count(), 1)

        link = LinkModel.objects.first()
        self.assertEqual(link.titulo, "Google")
        self.assertEqual(link.link, "https://google.com")
        self.assertEqual(link.observacao, "Site de pesquisa")

    def test_cadastro_post_link_invalido_nao_salva(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google",
            "link": "link errado",
            "observacao": "Site de pesquisa"
        }

        response = self.client.post(reverse("cadastro"), dados)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(LinkModel.objects.count(), 0)
        self.assertContains(response, "Informe uma URL válida")

    def test_cadastro_titulo_obrigatorio(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "",
            "link": "https://google.com",
            "observacao": "Site de pesquisa"
        }

        response = self.client.post(reverse("cadastro"), dados)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(LinkModel.objects.count(), 0)
        self.assertContains(response, "Informe o título do link.")

    def test_cadastro_link_obrigatorio(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google",
            "link": "",
            "observacao": "Site de pesquisa"
        }

        response = self.client.post(reverse("cadastro"), dados)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(LinkModel.objects.count(), 0)
        self.assertContains(response, "Informe o link.")

    def test_cadastro_observacao_pode_ser_vazia(self):
        self.client.login(username="admin", password="123mudar")

        dados = {
            "titulo": "Google",
            "link": "https://google.com",
            "observacao": ""
        }

        response = self.client.post(reverse("cadastro"), dados)

        self.assertEqual(response.status_code, 302)
        self.assertEqual(LinkModel.objects.count(), 1)

        link = LinkModel.objects.first()
        self.assertEqual(link.observacao, "")