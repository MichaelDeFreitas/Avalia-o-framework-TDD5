from django.contrib.auth.models import User
from django.test import TestCase, Client
from django.urls import reverse
from core.models import LinkModel


class ExcluirTest(TestCase):

    def setUp(self):
        self.client = Client()

        self.user = User.objects.create_user(
            username="admin",
            email="admin@cps.sp.gov.br",
            password="123mudar"
        )

        self.link = LinkModel.objects.create(
            titulo="Google",
            link="https://google.com",
            observacao="Site de pesquisa"
        )

    def test_excluir_precisa_de_login(self):
        response = self.client.get(reverse("excluir", args=[self.link.id]))

        self.assertEqual(response.status_code, 302)

    def test_excluir_get_logado_abre_pagina(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("excluir", args=[self.link.id]))

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "excluir.html")
        self.assertContains(response, "Excluir Link")
        self.assertContains(response, "Google")

    def test_excluir_post_remove_link(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.post(reverse("excluir", args=[self.link.id]))

        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse("listar"))
        self.assertFalse(LinkModel.objects.filter(id=self.link.id).exists())

    def test_excluir_get_nao_remove_link(self):
        self.client.login(username="admin", password="123mudar")

        response = self.client.get(reverse("excluir", args=[self.link.id]))

        self.assertEqual(response.status_code, 200)
        self.assertTrue(LinkModel.objects.filter(id=self.link.id).exists())