from django.urls import path
from core.views import login, logout, home, cadastro, listar, editar, excluir


urlpatterns = [
    path('login/', login, name='login'),
    path('logout/', logout, name='logout'),
    path('index/', home, name='index'),
    path('', home,name='home'),
    path('cadastro/',cadastro, name='cadastro'),
    path('listar/',listar,  name='listar'),
    path('editar/<int:id>/', editar, name='editar'),
    path('excluir/<int:id>/', excluir, name='excluir'), 
]